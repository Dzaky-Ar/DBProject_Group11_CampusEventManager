<?php
$proposal = filter_input(INPUT_POST, 'proposal', FILTER_SANITIZE_STRING);
$org = filter_input(INPUT_POST, 'organizer', FILTER_SANITIZE_STRING);


$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["file"]["name"]);
$uploadOk = 1;
$FileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

  echo $FileType . "------"; 
  if(preg_match('/(pdf)/', $FileType)) {
    echo 'Valid';
  }else{
    echo "Invalid type <br>";
  }


require_once 'config.php';

if($conn-> connect_error){
    die('Connect Error ('. $conn->connect_errno .')' .$conn->connect_error);
} else{
    $stmt = $conn->prepare("Insert into proposal_try(description,organizerID) values (?,?)");
    if($stmt === false){
        die('Prepare Failed: ' . $conn->error);
    }

    $stmt->bind_param("si",$proposal,$org);

    
}

if($stmt->execute()){
    //echo "Success" . "<br>  ";
} else{
    echo "error" . $stmt->error;
}
$stmt->close();

$result = $conn->query("SELECT * FROM proposal_try");


if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    foreach($row as $field){
        echo($field . " ");
    }
    echo "<br>";
  }
} else {
  echo "0 results";
}
$conn->close();
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Proposal Submitted</title>
    <a href="form.html">back</a>


