<?php
include_once 'config.php';

class Event {
    private $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    // Ambil semua jadwal event dengan lokasi
    public function getAllEvents() {
        $query = "SELECT e.Event_ID, e.Nama_event, e.Tipe_event, e.Description, 
                         l.Lokasi, l.Waktu, o.Nama_organizer as organizerName
                  FROM Event e 
                  LEFT JOIN Location l ON e.Event_ID = l.Event_ID 
                  LEFT JOIN Organizer o ON e.Organizer_ID = o.Organizer_ID
                  ORDER BY l.Waktu ASC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    // Ambil event berdasarkan ID
    public function getEventById($eventID) {
        $query = "SELECT e.Event_ID, e.Nama_event, e.Tipe_event, e.Description, 
                         l.Lokasi, l.Waktu, o.Nama_organizer as organizerName
                  FROM Event e 
                  LEFT JOIN Location l ON e.Event_ID = l.Event_ID 
                  LEFT JOIN Organizer o ON e.Organizer_ID = o.Organizer_ID
                  WHERE e.Event_ID = :eventID";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':eventID', $eventID);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Ambil event yang sedang berlangsung (untuk dashboard user)
    public function getUpcomingEvents() {
        $query = "SELECT e.Event_ID, e.Nama_event, e.Tipe_event, e.Description, 
                         l.Lokasi, l.Waktu, o.Nama_organizer as organizerName
                  FROM Event e 
                  LEFT JOIN Location l ON e.Event_ID = l.Event_ID 
                  LEFT JOIN Organizer o ON e.Organizer_ID = o.Organizer_ID
                  WHERE l.Waktu >= CURDATE()
                  ORDER BY l.Waktu ASC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }
}
?>