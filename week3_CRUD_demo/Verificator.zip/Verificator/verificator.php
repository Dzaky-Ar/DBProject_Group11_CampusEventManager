<?php
include_once 'config.php';

class Verificator {
    private $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    // Ambil proposal yang belum di-approve (pending dan not approved)
    public function getPendingProposals() {
        $query = "SELECT p.Proposal_ID, p.Description, p.File, p.Status, 
                         o.Nama_organizer as organizerName, o.Organizer_ID,
                         v.Verificator_ID, v.Nama_PJ
                  FROM Proposal p
                  LEFT JOIN Organizer o ON p.Organizer_ID = o.Organizer_ID
                  LEFT JOIN Verificator v ON p.Verificator_ID = v.Verificator_ID
                  WHERE p.Status IN ('pending', 'not approved')
                  ORDER BY p.Proposal_ID DESC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    // Ambil history proposal yang sudah di-approve
    public function getApprovedProposals() {
        $query = "SELECT p.Proposal_ID, p.Description, p.File, 
                         o.Nama_organizer as organizerName, o.Organizer_ID,
                         v.Verificator_ID, v.Nama_PJ, p.Status
                  FROM Proposal p
                  LEFT JOIN Organizer o ON p.Organizer_ID = o.Organizer_ID
                  LEFT JOIN Verificator v ON p.Verificator_ID = v.Verificator_ID
                  WHERE p.Status = 'approved'
                  ORDER BY p.Proposal_ID DESC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    // Update status proposal
    public function updateProposalStatus($proposalID, $status, $verificatorID) {
        $query = "UPDATE Proposal SET Status = :status, Verificator_ID = :verificatorID 
                  WHERE Proposal_ID = :proposalID";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':status', $status);
        $stmt->bindParam(':verificatorID', $verificatorID);
        $stmt->bindParam(':proposalID', $proposalID);

        return $stmt->execute();
    }

    // Ambil inventaris untuk verificator
    public function getInventaris() {
        $query = "SELECT Kode_barang, Nama_barang, Jumlah_barang FROM Inventory ORDER BY Nama_barang";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    // Assign inventaris ke event (tabel gives)
    public function assignInventarisToEvent($kodeBarang, $eventID) {
        $query = "INSERT INTO gives (Kode_barang, Event_ID) VALUES (:kodeBarang, :eventID)";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':kodeBarang', $kodeBarang);
        $stmt->bindParam(':eventID', $eventID);
        return $stmt->execute();
    }

    // Hapus inventaris dari event (setelah event selesai)
    public function removeInventarisFromEvent($kodeBarang, $eventID) {
        $query = "DELETE FROM gives WHERE Kode_barang = :kodeBarang AND Event_ID = :eventID";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':kodeBarang', $kodeBarang);
        $stmt->bindParam(':eventID', $eventID);
        return $stmt->execute();
    }

    // Update jumlah inventaris setelah event selesai
    public function updateInventarisAfterEvent($kodeBarang, $jumlah) {
        $query = "UPDATE Inventory SET Jumlah_barang = Jumlah_barang + :jumlah WHERE Kode_barang = :kodeBarang";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':kodeBarang', $kodeBarang);
        $stmt->bindParam(':jumlah', $jumlah);
        return $stmt->execute();
    }
}
?>