<?php
include_once 'verificator.php';
include_once 'event.php';

session_start();
if (!isset($_SESSION['email']) || $_SESSION['statusUser'] < 3) {
    header("Location: login.php");
    exit();
}

$verificator = new Verificator();
$event = new Event();

if ($_POST) {
    if (isset($_POST['approve_proposal'])) {
        $verificator->updateProposalStatus($_POST['proposalID'], 'approved', 1);
    } elseif (isset($_POST['reject_proposal'])) {
        $verificator->updateProposalStatus($_POST['proposalID'], 'not approved', 1);
    }
}

$pending_proposals = $verificator->getPendingProposals();
$approved_proposals = $verificator->getApprovedProposals();
$inventaris = $verificator->getInventaris();
$events = $event->getAllEvents();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard Verificator</title>
</head>
<body>
    <h1>Dashboard Verificator</h1>
    <p>Welcome, <?php echo $_SESSION['username']; ?> | <a href="logout.php">Logout</a></p>
    
    <h2>Proposal Pending</h2>
    <table border="1" cellpadding="5">
        <tr>
            <th>ID</th><th>Organizer</th><th>Deskripsi</th><th>Status</th><th>Aksi</th>
        </tr>
        <?php while ($row = $pending_proposals->fetch(PDO::FETCH_ASSOC)): ?>
        <tr>
            <td><?= $row['Proposal_ID'] ?></td>
            <td><?= $row['organizerName'] ?></td>
            <td><?= $row['Description'] ?></td>
            <td><?= $row['Status'] ?></td>
            <td>
                <form method="POST" style="display:inline;">
                    <input type="hidden" name="proposalID" value="<?= $row['Proposal_ID'] ?>">
                    <button type="submit" name="approve_proposal">Approve</button>
                </form>
                <form method="POST" style="display:inline;">
                    <input type="hidden" name="proposalID" value="<?= $row['Proposal_ID'] ?>">
                    <button type="submit" name="reject_proposal">Reject</button>
                </form>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>

    <h2>History Proposal Approved</h2>
    <table border="1" cellpadding="5">
        <tr>
            <th>ID</th><th>Organizer</th><th>Deskripsi</th><th>Verificator</th>
        </tr>
        <?php while ($row = $approved_proposals->fetch(PDO::FETCH_ASSOC)): ?>
        <tr>
            <td><?= $row['Proposal_ID'] ?></td>
            <td><?= $row['organizerName'] ?></td>
            <td><?= $row['Description'] ?></td>
            <td><?= $row['Nama_PJ'] ?></td>
        </tr>
        <?php endwhile; ?>
    </table>

    <h2>Inventaris</h2>
    <table border="1" cellpadding="5">
        <tr><th>Kode</th><th>Nama Barang</th><th>Jumlah</th></tr>
        <?php while ($row = $inventaris->fetch(PDO::FETCH_ASSOC)): ?>
        <tr>
            <td><?= $row['Kode_barang'] ?></td>
            <td><?= $row['Nama_barang'] ?></td>
            <td><?= $row['Jumlah_barang'] ?></td>
        </tr>
        <?php endwhile; ?>
    </table>

    <h2>Jadwal Event</h2>
    <table border="1" cellpadding="5">
        <tr><th>Event</th><th>Lokasi</th><th>Waktu</th><th>Organizer</th></tr>
        <?php while ($row = $events->fetch(PDO::FETCH_ASSOC)): ?>
        <tr>
            <td><?= $row['Nama_event'] ?></td>
            <td><?= $row['Lokasi'] ?></td>
            <td><?= $row['Waktu'] ?></td>
            <td><?= $row['organizerName'] ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>