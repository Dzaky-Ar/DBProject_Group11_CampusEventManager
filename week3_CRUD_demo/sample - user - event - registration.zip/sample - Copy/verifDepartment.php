<!DOCTYPE html>
<html>
    <title>Verificator Department Page</title>

    <body>
        <p>This is a Verificator Department page!</p>
    </body>
</html>