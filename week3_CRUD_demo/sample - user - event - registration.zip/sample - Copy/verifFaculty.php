<!DOCTYPE html>
<html>
    <title>Verificator Faculty Page</title>

    <body>
        <p>This is a Verificator Faculty page!</p>
    </body>
</html>