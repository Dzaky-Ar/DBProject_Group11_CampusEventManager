<?php
session_start();
require_once "config.php";

// Fetch events from database
$events = [];
$result = $conn->query("SELECT * FROM Event");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $events[] = $row;
    }
}
?>

<!DOCTYPE html>
<html>
    <head>
        <title>User Page</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width-device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style_user.css">
    </head>

    <body>
        <?php
        if (isset($_SESSION['success_message'])) {
            echo "<p class='success-message'>" . $_SESSION['success_message'] . "</p>";
            unset($_SESSION['success_message']);
        }
        if (isset($_SESSION['error_message'])) {
            echo "<p class='error-message'>" . $_SESSION['error_message'] . "</p>";
            unset($_SESSION['error_message']);
        }
        ?>

        <div class="container">
            <h2>Available Events</h2>
            <button onclick="location.href='register_event.php'">Register for Event</button>
            <button onclick="location.href='my_submissions.php'">My Submissions</button>
            <button onclick="location.href='logout.php'">Logout</button>
            <table class="events-table spreadsheet">
                <thead>
                    <tr>
                        <th>Nama Event</th>
                        <th>Tipe Event</th>
                        <th>Description</th>
                        <th>Organizer ID</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($events as $event): ?>
                    <tr onclick="location.href='event_register.php?event_id=' + <?php echo $event['Event_ID']; ?>" style="cursor: pointer;">
                        <td><?php echo htmlspecialchars($event['Nama_event']); ?></td>
                        <td><?php echo htmlspecialchars($event['Tipe_event']); ?></td>
                        <td><?php echo htmlspecialchars($event['Description']); ?></td>
                        <td><?php echo htmlspecialchars($event['Organizer_ID']); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

    </body>
</html>
