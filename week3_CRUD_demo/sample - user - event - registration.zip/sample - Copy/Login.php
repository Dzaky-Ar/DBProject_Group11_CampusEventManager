<?php
session_start();

$errors = [
    'login' => $_SESSION['login_error'] ?? '',
    'register' => $_SESSION['register_error'] ??'',
];
$activeForm = $_SESSION['active_form'] ?? 'login';

session_unset();

function showError($error) {
    return !empty($error) ? "<p class='error-message'>$error</p>" : '';
}

function isActiveForm($formName, $activeForm) {
    return $formName === $activeForm ? 'active' : ' ';
}

?>

<!DOCTYPE html>
<html>
    <head>
        <title>Login</title>
        <link rel="stylesheet" href="style.css">
    </head>

    <body>
        <div class="container">
            <div class="form-box <?=  isActiveForm('login', $activeForm); ?>" id="login-form">
                <form action="Login_register.php" method="POST">
                    <h2 id="header">Login</h2>
                    <?= showError($errors['login']); ?>
                    <label for="email" id="subheader">Email</label>
                    <input type="email" name="Email" placeholder="Enter email" required>

                    <label for="password" id="subheader">Password</label>
                    <input type="text" name="Password" placeholder="Enter Password" required>
    
                    <button type="submit" name="login">Login</button>
                    <p>Don't have an account? <a href="Register.php">Register</a></p>
                </form>
            </div>
        </div>

        <script src="script.js"></script>

</html>