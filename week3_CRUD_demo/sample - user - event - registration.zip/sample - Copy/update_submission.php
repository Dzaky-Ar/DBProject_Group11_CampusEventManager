<?php
session_start();
require_once "config.php";

$submission = null;
if (isset($_GET['id'])) {
    $registration_id = $_GET['id'];
    $email = $_SESSION['Email'] ?? '';

    if ($email) {
        $sql = "SELECT s.Registration_ID, s.Judul, s.Submission, s.Event_ID, e.Nama_event FROM Registration s JOIN Event e ON s.Event_ID = e.Event_ID WHERE s.Registration_ID = ? AND s.Email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("is", $registration_id, $email);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $submission = $result->fetch_assoc();
        }
        $stmt->close();
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update'])) {
    $judul = $_POST['Judul'] ?? '';
    $registration_id = $_POST['Registration_ID'];
    $email = $_SESSION['Email'] ?? '';
    $file_content = null;

    // Handle file upload if provided
    if (isset($_FILES["submission_pdf"]) && $_FILES["submission_pdf"]["error"] == 0) {
        $file_name = $_FILES["submission_pdf"]["name"];
        $file_tmp = $_FILES["submission_pdf"]["tmp_name"];
        $file_size = $_FILES["submission_pdf"]["size"];
        $file_type = $_FILES["submission_pdf"]["type"];

        // Check if file is PDF
        if ($file_type == "application/pdf") {
            $file_content = file_get_contents($file_tmp);
            if ($file_content === false) {
                $_SESSION['error_message'] = "Failed to read file.";
                header("Location: update_submission.php?id=$registration_id");
                exit();
            }
        } else {
            $_SESSION['error_message'] = "Only PDF files are allowed.";
            header("Location: update_submission.php?id=$registration_id");
            exit();
        }
    }

    // Update database
    if ($file_content !== null) {
        $sql = "UPDATE Registration SET Judul = ?, Submission = ? WHERE Registration_ID = ? AND Email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sbis", $judul, $file_content, $registration_id, $email);
        $stmt->send_long_data(1, $file_content);
    } else {
        $sql = "UPDATE Registration SET Judul = ? WHERE Registration_ID = ? AND Email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sis", $judul, $registration_id, $email);
    }

    if ($stmt->execute()) {
        $_SESSION['success_message'] = "Submission updated successfully!";
    } else {
        $_SESSION['error_message'] = "Database error: " . $stmt->error;
    }
    $stmt->close();

    header("Location: my_submissions.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Update Submission</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style_user.css">
    </head>

    <body>
        <?php
        if (isset($_SESSION['success_message'])) {
            echo "<p class='success-message'>" . $_SESSION['success_message'] . "</p>";
            unset($_SESSION['success_message']);
        }
        if (isset($_SESSION['error_message'])) {
            echo "<p class='error-message'>" . $_SESSION['error_message'] . "</p>";
            unset($_SESSION['error_message']);
        }
        ?>

        <div class="container">
            <h2>Update Submission</h2>
            <?php if ($submission): ?>
                <form action="update_submission.php" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="Registration_ID" value="<?php echo $submission['Registration_ID']; ?>">

                    <label for="Judul">Judul:</label>
                    <input type="text" name="Judul" value="<?php echo htmlspecialchars($submission['Judul']); ?>">

                    <label for="submission_pdf">Upload New PDF (optional):</label>
                    <input type="file" name="submission_pdf" accept=".pdf">

                    <button type="submit" name="update">Update</button>
                </form>
            <?php else: ?>
                <p>Submission not found.</p>
            <?php endif; ?>
            <p><a href="my_submissions.php">Back to My Submissions</a></p>
        </div>
    </body>
</html>
