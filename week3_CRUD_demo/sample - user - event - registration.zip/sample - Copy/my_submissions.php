<?php
session_start();
require_once "config.php";

// Fetch user's submissions
$submissions = [];
$email = $_SESSION['Email'] ?? '';
if ($email) {
    $sql = "SELECT s.Registration_ID, s.Judul, s.Submission, s.Event_ID, e.Nama_event FROM Registration s JOIN Event e ON s.Event_ID = e.Event_ID WHERE s.Email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $submissions[] = $row;
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html>
    <head>
        <title>My Submissions</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style_user.css">
    </head>

    <body>
        <div class="container">
            <h2>My Event Submissions</h2>
            <?php if (empty($submissions)): ?>
                <p>You have no submissions yet.</p>
            <?php else: ?>
                <table class="events-table spreadsheet">
                    <thead>
                        <tr>
                            <th>Judul</th>
                            <th>Event Name</th>
                            <th>File</th>
                            <th>Update</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($submissions as $submission): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($submission['Judul']); ?></td>
                            <td><?php echo htmlspecialchars($submission['Nama_event']); ?></td>
                            <td>
                                <?php if ($submission['Submission']): ?>
                                    <a href="view_submission.php?id=<?php echo $submission['Registration_ID']; ?>" target="_blank">View PDF</a>
                                <?php else: ?>
                                    No file uploaded
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="update_submission.php?id=<?php echo $submission['Registration_ID']; ?>">Update</a>
                            </td>
                            <td>
                                <form action="cancel_submission.php" method="POST" style="display:inline;">
                                    <input type="hidden" name="Registration_id" value="<?php echo $submission['Registration_ID']; ?>">
                                    <button type="submit" name="cancel">Cancel</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
            <p><a href="user_page.php">Back to Events</a></p>
        </div>
    </body>
</html>
