<?php
session_start();

$errors = [
    'login' => $_SESSION['login_error'] ?? '',
    'register' => $_SESSION['register_error'] ??'',
];
$activeForm = $_SESSION['active_form'] ?? 'login';

session_unset();

function showError($error) {
    return !empty($error) ? "<p class='error-message'>$error</p>" : '';
}

function isActiveForm($formName, $activeForm) {
    return $formName === $activeForm ? 'active' : ' ';
}

?>

<!DOCTYPE html>
<html>
    <head>
        <title>Register</title>
        <link rel="stylesheet" href="style.css">
    </head>

    <body>
        <div class="container">
            <div class="form-box <?=  isActiveForm('register', $activeForm); ?>" id="login-form">
                <form action="Login_register.php" method="POST">
                    <h2 id="header">Register</h2>
                    <?= showError($errors['register']); ?>

                    <label for="username">Username</label>
                    <input type="text" name="User_name" placeholder="Enter Username" required>

                    <label for="email">Email</label>
                    <input type="email" name="Email" placeholder="Enter email" required>

                    <label for="password">Password</label>
                    <input type="text" name="Password" placeholder="Enter Password" required>
    
                    <label for="status">Status</label>
                    <select name="Status_user" id="Status_user" required>
                        <option value="">--Select Status--</option>
                        <option value="1">Verificator Universitas</option>
                        <option value="2">Verificator Fakultas</option>
                        <option value="3">Verificator Departemen</option>
                        <option value="4">Organizer</option>
                        <option value="5">Guest/User</option>
                    </select>
                    <button type="submit" name="register">Register</button>
                    <p>Already have an account? <a href="Login.php">Login</a></p>
                </form>
            </div>
        </div>
</html>