<?php
session_start();
require_once "config.php";

if (isset($_POST["register"])) {
    $name = $_POST["User_name"];
    $email = $_POST["Email"];
    $password = password_hash($_POST["Password"], PASSWORD_DEFAULT);
    $status = $_POST["Status_user"];

    $checkEmail = $conn->query("SELECT Email FROM User WHERE Email ='$email'");
    if ($checkEmail && $checkEmail->num_rows > 0) {
        $_SESSION["register_error"] = "Email is already registered!";
        $_SESSION["active_form"] = "register";
    } else {
        // NOTE: consider using prepared statements to avoid SQL injection
        $conn->query("INSERT INTO User (User_name, Email, Password, Status_user)
        VALUES ('$name', '$email', '$password', '$status')");
    }

    header("Location: register.php");
    exit();
}
if (isset($_POST["login"])) {
    $email = $_POST["Email"];
    $password = $_POST["Password"];

    $result = $conn->query("SELECT * FROM User WHERE Email ='$email'");
    if ($result && $result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['Password'])) {
            $_SESSION['User_name'] = $user['User_name'];
            $_SESSION['Email'] = $user['Email'];

            if ($user['Status_user'] == '1') {
                header("Location: verifUniv.php");
            } else if ($user['Status_user'] == '2') {
                header("Location: verifFaculty.php");
            } else if ($user['Status_user'] == '3') {
                header("Location: verifDepartment.php");
            } else if ($user['Status_user'] == '4') {
                header("Location: organizer_page.php");
            } else if ($user['Status_user'] == '5') {
                header("Location: user_page.php");
            } else {
                header("Location: register.php");
            }
            exit();
        } 
    }

    $_SESSION['login_error'] = 'Invalid email or password';
    $_SESSION['active_form'] = 'login';
    header("Location: login.php");
    exit();
     
}


?>