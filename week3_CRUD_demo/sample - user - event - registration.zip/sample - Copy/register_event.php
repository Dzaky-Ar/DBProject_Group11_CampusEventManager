<?php
session_start();
require_once "config.php";

// Fetch events from database
$events = [];
$result = $conn->query("SELECT * FROM Event");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $events[] = $row;
    }
}
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Register for Event</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style_user.css">
    </head>

    <body>
        <?php
        if (isset($_SESSION['success_message'])) {
            echo "<p class='success-message'>" . $_SESSION['success_message'] . "</p>";
            unset($_SESSION['success_message']);
        }
        if (isset($_SESSION['error_message'])) {
            echo "<p class='error-message'>" . $_SESSION['error_message'] . "</p>";
            unset($_SESSION['error_message']);
        }
        ?>

        <div class="container">
            <h2>Register for Event</h2>
            <form action="submit_form.php" method="POST" enctype="multipart/form-data">
                <label for="event_id">Select Event:</label>
                <select name="event_id" id="event_id" required>
                    <option value="">--Select Event--</option>
                    <?php foreach ($events as $event): ?>
                        <option value="<?php echo $event['Event_ID'] . '|' . htmlspecialchars($event['Nama_event']); ?>"><?php echo htmlspecialchars($event['Nama_event']); ?></option>
                    <?php endforeach; ?>
                </select>

                <label for="Judul">Judul:</label>
                <input type="text" name="Judul" placeholder="Enter Judul">

                <label for="submission_pdf">Upload PDF:</label>
                <input type="file" name="submission_pdf" accept=".pdf">

                <button type="submit" name="submit_item">Submit</button>
            </form>
        </div>
    </body>
</html>
