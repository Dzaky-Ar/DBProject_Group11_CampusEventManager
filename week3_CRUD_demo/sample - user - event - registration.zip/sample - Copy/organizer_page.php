<!DOCTYPE html>
<html>
    <title>Organizer Page</title>

    <body>
        <p>This is an Organizer page!</p>
    </body>
</html>