<!DOCTYPE html>
<html>
    <title>Verificator University Page</title>

    <body>
        <p>This is a Verificator University page!</p>
    </body>
</html>