<?php
include_once 'auth.php';

if ($_POST) {
    $auth = new Auth();
    $result = $auth->register($_POST['email'], $_POST['password'], $_POST['username']);
    
    if ($result['success']) {
        header("Location: login.php?message=registrasi_berhasil");
        exit();
    } else {
        $error_message = $result['message'];
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
</head>
<body>
    <h2>Register</h2>
    
    <?php if (isset($error_message)) echo "<p style='color:red;'>$error_message</p>"; ?>
    
    <form method="POST">
        <p>Email: <input type="email" name="email" required></p>
        <p>Username: <input type="text" name="username" required></p>
        <p>Password: <input type="password" name="password" required></p>
        <button type="submit">Register</button>
    </form>
    
    <p><a href="login.php">Sudah punya akun? Login</a></p>
</body>
</html>