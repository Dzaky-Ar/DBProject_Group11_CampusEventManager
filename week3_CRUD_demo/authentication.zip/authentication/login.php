<?php
include_once 'auth.php';
session_start();

if ($_POST) {
    $auth = new Auth();
    $result = $auth->login($_POST['email'], $_POST['password']);
    
    if ($result['success']) {
        $_SESSION['email'] = $result['email'];
        $_SESSION['statusUser'] = $result['statusUser'];
        $_SESSION['username'] = $result['username'];
        
        switch($result['statusUser']) {
            case '5': header("Location: user_dashboard.php"); break;
            case '4': header("Location: organizer_dashboard.php"); break;
            case '1': case '2': case '3': header("Location: verificator_dashboard.php"); break;
            default: header("Location: login.php?error=unknown_role");
        }
        exit();
    } else {
        $error_message = $result['message'];
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
</head>
<body>
    <h2>Login</h2>
    
    <?php if (isset($error_message)) echo "<p style='color:red;'>$error_message</p>"; ?>
    <?php if (isset($_GET['message']) && $_GET['message'] == 'registrasi_berhasil') echo "<p style='color:green;'>Registrasi berhasil!</p>"; ?>
    
    <form method="POST">
        <p>Email: <input type="email" name="email" required></p>
        <p>Password: <input type="password" name="password" required></p>
        <button type="submit">Login</button>
    </form>
    
    <p><a href="register.php">Buat akun baru</a> | <a href="forgot_password.php">Lupa password?</a></p>
</body>
</html>