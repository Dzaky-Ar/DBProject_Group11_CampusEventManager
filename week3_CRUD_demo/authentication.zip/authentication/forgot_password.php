<?php
include_once 'auth.php';

if ($_POST) {
    $auth = new Auth();
    $email = $_POST['email'];
    
    if ($auth->verifyEmail($email)) {
        $result = $auth->resetPassword($email, '123456');
        if ($result['success']) {
            $message = "Password berhasil direset ke: 123456";
        } else {
            $error_message = $result['message'];
        }
    } else {
        $error_message = "Email tidak ditemukan";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Lupa Password</title>
</head>
<body>
    <h2>Lupa Password</h2>
    
    <?php if (isset($error_message)) echo "<p style='color:red;'>$error_message</p>"; ?>
    <?php if (isset($message)) echo "<p style='color:green;'>$message</p>"; ?>
    
    <form method="POST">
        <p>Email: <input type="email" name="email" required></p>
        <button type="submit">Reset Password</button>
    </form>
    
    <p><a href="login.php">Kembali ke Login</a></p>
</body>
</html>