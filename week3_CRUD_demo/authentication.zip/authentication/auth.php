<?php
include_once 'config.php';

class Auth {
    private $conn;
    private $table_name = "User";

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    // Login user
    public function login($email, $password) {
        $query = "SELECT Email, Password, Status_user, User_name FROM " . $this->table_name . " WHERE Email = :email";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':email', $email);
        $stmt->execute();

        if ($stmt->rowCount() == 1) {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if (password_verify($password, $row['Password'])) {
                if ($row['Status_user'] <= 5) {
                    return array(
                        'success' => true,
                        'email' => $row['Email'],
                        'statusUser' => $row['Status_user'],
                        'username' => $row['User_name']
                    );
                } else {
                    return array('success' => false, 'message' => 'Akun tidak aktif');
                }
            }
        }
        return array('success' => false, 'message' => 'Email atau password salah');
    }

    // Register user baru
    public function register($email, $password, $username, $statusUser = '1') {
        // Cek apakah email sudah terdaftar
        $query = "SELECT Email FROM " . $this->table_name . " WHERE Email = :email";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':email', $email);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            return array('success' => false, 'message' => 'Email sudah terdaftar');
        }

        // Hash password dan simpan user
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $query = "INSERT INTO " . $this->table_name . " (Email, Password, User_name, Status_user) VALUES (:email, :password, :username, :statusUser)";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':password', $hashed_password);
        $stmt->bindParam(':username', $username);
        $stmt->bindParam(':statusUser', $statusUser);

        if ($stmt->execute()) {
            return array('success' => true, 'message' => 'Registrasi berhasil');
        }
        return array('success' => false, 'message' => 'Registrasi gagal');
    }

    // Reset password
    public function resetPassword($email, $new_password) {
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $query = "UPDATE " . $this->table_name . " SET Password = :password WHERE Email = :email";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':password', $hashed_password);
        $stmt->bindParam(':email', $email);

        if ($stmt->execute()) {
            return array('success' => true, 'message' => 'Password berhasil direset');
        }
        return array('success' => false, 'message' => 'Reset password gagal');
    }

    // Verifikasi email untuk reset password
    public function verifyEmail($email) {
        $query = "SELECT Email FROM " . $this->table_name . " WHERE Email = :email";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':email', $email);
        $stmt->execute();

        return $stmt->rowCount() > 0;
    }
}
?>